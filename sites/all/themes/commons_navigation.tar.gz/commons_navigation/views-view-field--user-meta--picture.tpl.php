<?php
 /**
  * This template is blank for the purpose of removing the user picture
  */
?>
